
//Kirsty Ihenetu
//@UNI: mki2104
//Class that makes the card object

public class Card implements Comparable<Card>{
	
    private int suit; //use integers 1-4 to encode the suit
    private int rank; //use integers 1-13 to encode the rank
    private String suitName;
    private String rankNumber;
        
    public Card(int s, int r){
        //make a card with suit s and rank r
        suit=s;
        rank=r;
    }
	
    public int compareTo(Card c){
       
      int answer=0;
        
      if (this.rank>c.rank){
          answer=1;
        }
      else{
          answer=-1;
        }
        
      if(this.rank==c.rank){
         
        if(this.suit>c.suit){
             answer= 1;
              }
        else{
             answer= -1;
              }
               
      }  

    return answer;  
    }
   
   public int getSuit(){
        //encode the suit as integers
       
       int clubs=1;
       int diamonds=2;
       int hearts=3;
       int spades=4;
       
    return suit;
    }
    
   public int getRank(){
    
       int A=1;
       int J=11;
       int Q=12;
       int K=13;
   return rank; 
   }
	
    public String toString(){
        //use this method to easily print a Card object
     String[] rankNumber= {"A", "2", "3", "4", "5", "6", "7", "8", "9",
                           "10", "J", "Q", "K"};
     String[] suitName= {"clubs","diamonds","hearts","spades"};
     String cardName= rankNumber[rank-1]+" of "+ suitName[suit-1];
     return cardName;
    }
    
    //add some more methods here if needed

}
