
//Kirsty Ihenetu
//@UNI: mki2104
//Creates a deck of cards, shuffle a deck of cards, and deals a 'n' number of cards

public class Deck {
	
    private Card[] cards;
    private int top; //the index of the top of the deck
    private int exchangeCard;
    //add more instance variables if needed
	
    public Deck(){
    //make a 52 card deck here
        cards= new Card[52];

            int count = 0;
            for (int s = 0; s < 4; s++) {
                 for (int r = 0; r < 13;r++) {
                     cards[count] = new Card(s + 1, r + 1);
                     count++;
                 }
            }
        shuffle();
        top=0;
        }
   
    public void shuffle(){
    //shuffle the deck here
       int randomCard;
       int currentCard;
       Card temp;
       for(int i=0; i<cards.length-1;i++){
         randomCard= (int) (Math.random()*cards.length); //30
         currentCard= (int)(Math.random()*cards.length);
         temp= cards[currentCard];                         //40
         cards[currentCard]=cards[randomCard]; //cards[40] = cards[30]
         cards[randomCard]=temp; //cards[30] = cards[40] (=cards[30])
       }
    }
    
    public Card deal(){
    // deal a single card here
    top++;
    return cards[top]; 
    }


}
