Card.java-
Card(): The Card constructor initializes the instance variables
in order to make a card object.
compareTo(): The compareTo method was a tool to compare 
between cards based on rank then suit in ascending order.
getSuit(): The getSuit method was an accessor method that was
able to access the suit of a given card for further comparison in Game Class
checkHand method.
getRank: The getRank method was an accessor method that was
able to access the rank of a given card for further comparison in Game Class
checkHand method.
toString(): The toString method was a mutator method that takes the encoded
suits and ranks are converted.  

Deck.java- 
Deck(): Deck() constructs a card deck of 52 cards with a nested for loop 
that prints the suits(1-4) and the ranks (1-13). Then at the end of the deck, I
call the shuffle method to randomize the deck.

shuffle(): the shuffle method chooses two cards out of the deck to swap.
I did this by using math.random() method to generate a random number
and call that out of the existing deck. I did this for 2 cards. Then I made
a temp variable that would store the "current card" in order for it to be 
swapped with the random card.

deal(): deal()is a simple accessor method that returns the top
the card in the deck.


Game.java-

Game(String []testHand): the testHand method takes in a string passed in 
through the terminal and converts it into a new hand. I do this by using a nested
for loop going through the string and the ranks (1-13). Then inside the ranks I 
assign values to the suit characters ("c", "d", etc) and add the card to the hand.
Then I print the hand. 

Game(): In the game constructor I initialized the instance variables of
the Game Class. 

Play(): In the play() I used made a new deck of cards and shuffled it 
(for each game). Then in order to have a looping game function, I put the rest 
of the method in a while loop with the instance variable playAgain equal to 1.
Then I greeted the user and asked them what they wanted to bet. 
With their input, I altered the bankroll(found in player.java)
through bets() and getBankRoll().I proceeded to make a hand of cards using my
makeHand (). In my makeHand() method, I use the method deal() in the deck class and
add() to copy new cards in my "hand" ArrayList. Then I printed the hand in the 
my play(). Then called my exchange() method. What I did in my exchange() was:
Ask which index of card the user wanted to exchange and then used the set() method of 
Arraylists to copy a random card to that index. Then I called the checkHand() method. 
In the checkHand(), I utilized the getRank() from card class and get() from arraylist.
I used them as well as the compareTo() through the Collection.sort() to compare whether
ranks or suits are the same. After calling the checkHand().
I store the return value of checkHand into another variable “wins”. After that 
following the instructions of the assignment I multiply wins by amt(the user's bet).
I stored that into a variable "payout". Then I used the mutator method winnings() to
adjust the bankroll and printed the payout and updated bankroll. At the end of the 
round the user is asked if they want to play again to break out of the while loop
they can press 0 for no. 


testPlay(): this accessor method is used to test the return value of the 
checkHand() method. It does this by calling the checkHand().


Player.java-
Player(): the player constructor is where initialized the instance variables
to make a player.
bets(): the bets are where I subtracted from the bankroll to make a bet.
winnings(): the winnings is where I added the explict parameter to the bankroll.
getBankRoll(): This is where I call the updated bankroll.


