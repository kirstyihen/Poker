
//Kirsty Ihenetu
//@mki2104
//This classes makes a player, makes a bet, 
//picks cards to exchange, and adjusts the bankroll

public class Player {
	
		
    private int bankroll;
    private int bet;
   
    //you may choose to use more instance variables
		
    public Player(){		
        //create a player here
        bankroll=100;
        bet=0;
    }
	
    public void bets(int amt){
        //player makes a bet
       bankroll-=amt;
    }
 
    public void winnings(int wins){
       //adjust bankroll if player wins
       bankroll+=wins;
    }

    public int getBankroll(){
        //return current balance of bankroll
        return bankroll;
    }

    //you may wish to use more methods here
}


