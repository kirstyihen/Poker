
// Kirsty Ihenetu
//@mki2104
//To make and play a game of video poker

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class Game {
    private int wins;// this is works as odds
    private int playAgain;
    private Deck cards;
    private Scanner input;
    private Player p;
    private Card singleCard;
    private ArrayList<Card>hand;
    
    // you may want some more here
	
    public Game(String[] testHand){
       
        cards= new Deck();
        p= new Player();
        hand= new ArrayList<Card>();
        for(int i=0; i< testHand.length; i++){
           for(int rank=1; rank<13; rank++){
            String suit= testHand[i].substring(0);
            int suitNumber=0;
            if(suit.equals("c")){
               suitNumber=1;
            }
            if(suit.equals("d")){
                suitNumber=2;
            }
             if(suit.equals("h")){
                suitNumber=3;
             }
             if(suit.equals("s")){
                 suitNumber=4;
             }
            Card singleCard= new Card(suitNumber,rank);
            hand.add(singleCard);
         }
      }
  makeHand();
  }

	
    public Game(){
    // This no-argument constructor is to actually play a normal game
     wins=0;
     playAgain=1;
     cards= new Deck();
     input= new Scanner(System.in);
     p= new Player();
     singleCard= cards.deal();
     hand= new ArrayList<Card>();
    }
    
    public void play(){
        // this method should play the game	
        cards= new Deck();
        cards.shuffle();
       while(playAgain==1){
        Scanner input= new Scanner(System.in);
        System.out.println("Welcome to video poker! Bankroll:"+p.getBankroll());
        System.out.println("How much would you like to bet? 1-5 tokens");
        int amt= input.nextInt();
        p.bets(amt); 
        System.out.println("Bankroll: "+p.getBankroll());
        System.out.println(makeHand()); 
        
        System.out.println("Would you like to exchange cards? 0=No, 1=yes");
       //System.out.println(hand);
       int swap=input.nextInt();
       if(swap==1){
       System.out.println("How many cards would you like to exchange? 1-5?");
       int exchange= input.nextInt();
      
        for(int i=0; i<exchange; i++){
        System.out.println("Which cards would you like to exchange? 1-5");
        int index= input.nextInt();
        exchange(index-1);
        System.out.println(hand);
        }
       }
       
        checkHand();
        int payout= wins*amt;
        p.winnings(payout);
        System.out.println("You won: "+ payout +" tokens!");
        
        System.out.println("Bankroll: "+p.getBankroll());
           
        System.out.println("That was fun! Wanna play again? 1=Yes, 0=No");
        
        int yes=1;
        int no=0;
        int restart= input.nextInt();
            if(restart==0){
               playAgain=0; 
            }
            else{
                playAgain=1;
            }
       
     }
   }	
    
		
    public ArrayList makeHand(){  
      hand= new ArrayList<Card>();
      for(int i=0; i<5; i++){
          hand.add(cards.deal());
         }
    return hand;
    }
    
    public void exchange(int i){
        
      hand.set(i,singleCard);
    }

    public void testPlay(){
        checkHand();
    }
    
    public int checkHand(){
       if(callRoyalFlush()==250){
          System.out.println("Royal Flush");
          return callRoyalFlush();
        }
        else if(callStraightFlush()==50){
           System.out.println("Straight Flush");
           return callStraightFlush();
        }
        else if(callFourOfaKind()==25){
           System.out.println("Four Of a Kind");
           return callFourOfaKind();
        }
         else if(callFullHouse()==6){
           System.out.println("Full House");
           return callFullHouse();
        }
        else if(callFlush()==5){
           System.out.println("Flush");
           return callFlush();
        }
        else if(callStraight()==4){
           System.out.println("Straight");
           return callStraight();
        }
        else if(callThreeOfaKind()==3){
           System.out.println("Three Of a Kind");
           return callThreeOfaKind();
        }
        else if(callTwoPair()==2){
           System.out.println("Two Pair");
           return callTwoPair();
        }
        else if(callOnePair()==1){
           System.out.println("One Pair");
           return callOnePair();
        }
        else{
           System.out.println("No Pair");
           return callNoPair();
        }

    }
    
   public int callRoyalFlush(){
     wins=0;
     if(callStraightFlush()==50){
        if(hand.get(4).getRank()==12){
           wins=250;
          }
       }
    return wins;
    }
    
    public int callStraightFlush(){
       wins=0;
       if((callStraight()+callFlush())==9){
          wins=50;
       }
    return wins;
    }
    
    public int callFourOfaKind(){
       wins=0;
       Collections.sort(hand);
       if((hand.get(0).getRank()==hand.get(3).getRank()
           ||hand.get(1).getRank()==hand.get(4).getRank())){
           
           wins=25;
       }
    return wins;
    }
    
    public int callFullHouse(){
       wins=0;
       if((callThreeOfaKind()+callOnePair())==4){
          wins=6;
       }
    return wins;
    }
    
   public int callFlush(){
       wins=0;
       if(hand.get(0).getSuit()==hand.get(1).getSuit()
         && hand.get(2).getSuit()==hand.get(1).getSuit()
         && hand.get(2).getSuit()==hand.get(3).getSuit()
         && hand.get(3).getSuit()==hand.get(4).getSuit()){
         wins=5;
       }
    return wins;
    }
    
   public int callStraight(){
       wins=0;
       Collections.sort(hand);
       int currentValue=0;
       if(hand.get(1).getRank()==10 &&callOnePair()==0){
          currentValue=1;
       for(int i=currentValue; i<hand.size()-1; i++){
           Card j= hand.get(i);
           Card k= hand.get(i+1);
           if(k.getRank()-j.getRank()!= 1){
              wins=4;
           }
       }
     }
    return wins;
    }
    
    public int callThreeOfaKind(){
        wins=0;
        Collections.sort(hand);
        if((hand.get(0).getRank()==hand.get(2).getRank()
           ||hand.get(2).getRank()==hand.get(4).getRank())){
          wins=3;  
        }

    return wins;
    }
    
   public int callTwoPair(){
       wins=0;
       Collections.sort(hand);
       if(hand.get(0).getRank()==hand.get(1).getRank()
          &&hand.get(2).getRank()==hand.get(3).getRank()
          ||hand.get(0).getRank()==hand.get(1).getRank()
          &&hand.get(3).getRank()==hand.get(4).getRank()
          ||hand.get(1).getRank()==hand.get(2).getRank()
          &&hand.get(3).getRank()==hand.get(4).getRank()){
          
          wins=2;
       }
    
    return wins;
    } 
    
  public int callOnePair(){
      wins=0;
      Collections.sort(hand);
      for(int i=0; i<hand.size()-1; i++){
          int j= i+1;
          if(hand.get(i).getRank()==hand.get(j).getRank()){
             wins=1; 
          }
      }   
    return wins;
    }

    public int callNoPair(){
      if(callRoyalFlush()==0 && callStraightFlush()==0 
         && callFourOfaKind()==0 && callFullHouse()==0
         && callFlush()==0 && callStraight()==0 
         && callThreeOfaKind()==0 && callTwoPair()==0
         &&callOnePair()==0){
          
         wins=0;
      } 
    return wins;
    }
  
}
  

	
